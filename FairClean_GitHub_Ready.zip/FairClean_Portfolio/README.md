# FairClean — Fairness-Aware Data Cleaning for Machine Learning

**Python · Pandas · NumPy · scikit-learn · Data Cleaning · Counterfactual Fairness · Responsible AI**

> **Portfolio highlight:** In the Adult Income Logistic Regression experiment, the reported demographic-parity gap decreased from **0.3308 to 0.2427** (about **26.6%**), while other model/dataset combinations showed that the intervention was not universally beneficial. The project therefore focuses on measurement, transparency and model-dependent evaluation rather than claiming a universal fairness improvement.

FairClean is the framework I developed for my BSc (Hons) Computer Science Honours project at Edinburgh Napier University. It investigates whether unfair patterns can be identified and mitigated **during data cleaning**, before they become embedded in downstream machine-learning models.

The project extends counterfactual fairness from a diagnostic idea into a preprocessing workflow. It tests whether predictions change when a sensitive attribute is flipped, compares this with dataset-specific structural uplift tests, and applies targeted removal or reweighting while recording the action taken. The submitted prototype also labels a second diagnostic as “causal”; in the original notebooks that function mirrors the direct attribute-flip test, so this repository documents that limitation rather than presenting it as an independent causal model.

## Why I built it

Traditional data cleaning focuses on problems such as missing values, inconsistent labels and outliers. Those steps improve technical data quality, but they do not necessarily address discriminatory structure already present in a dataset.

FairClean explores a different question:

> Can counterfactual reasoning be used not only to detect unfairness, but also to guide data-cleaning interventions?

## How FairClean works

```text
Dataset
  ↓
Preprocessing & validation
  ↓
Baseline model
  ↓
┌──────────────────────────────────────┐
│ Counterfactual diagnostics           │
│ 1. Sensitive-attribute flip          │
│ 2. Prototype causal check*           │
│ 3. Structural uplift test            │
└──────────────────────────────────────┘
  ↓
Hybrid mitigation
  ├─ Direct / causal instability → remove row
  └─ Structural instability → reduce row weight
  ↓
Retrain model
  ↓
Re-evaluate fairness + retain cleaning log
```

The cleaning log makes each intervention traceable by recording whether a row triggered a diagnostic and whether it was removed or reweighted.\n\n\*For reproducibility, the repository retains the original prototype causal check. It is operationally identical to the sensitive-attribute flip in the submitted notebooks and should not be interpreted as a separate causal model.

## Experiments

I evaluated the framework across two employment-related datasets and two classification algorithms:

| Dataset | Model |
|---|---|
| Adult Income | Decision Tree |
| Adult Income | Logistic Regression |
| International Graduates | Decision Tree |
| International Graduates | Logistic Regression |

## Key results

| Dataset / model | DP gap before | DP gap after | Rows removed | Rows reweighted | Outcome |
|---|---:|---:|---:|---:|---|
| Adult — Logistic Regression | 0.3308 | **0.2427** | 6,087 | 27,586 | Fairness improved |
| Adult — Decision Tree | 0.1949 | 0.1969 | 706 | 36,564 | No improvement |
| International Graduates — Logistic Regression | 0.00045 | 0.00045 | 0 | 150,179 | Fairness unchanged |
| International Graduates — Decision Tree | 0.00042 | 0.00042 | 0 | 150,184 | Fairness unchanged |

The most important result is not that FairClean improves every model. It does not. The Adult Logistic Regression experiment reduced the demographic-parity gap from **0.3308 to 0.2427**, while the Adult Decision Tree did not improve on this measure. Both International Graduates models already had demographic-parity ratios close to 1 and showed no direct or causal instability.

That model-dependent behaviour is useful: it shows why fairness interventions need to be evaluated rather than assumed to work universally.

![Adult Income fairness comparison](results/figures/adult_demographic_parity_gap.png)

## Repository structure

```text
FairClean/
├── README.md
├── requirements.txt
├── data/
│   ├── README.md
│   ├── adult-income-preprocessed.csv
├── src/\n│   └── fairclean/\n│       ├── diagnostics.py\n│       ├── metrics.py\n│       ├── mitigation.py\n│       └── models.py\n├── tests/\n│   └── test_fairclean.py\n├── notebooks/
│   ├── 01_adult_decision_tree_fairclean.ipynb
│   ├── 02_adult_logistic_regression_fairclean.ipynb
│   ├── 03_graduates_decision_tree_fairclean.ipynb
│   └── 04_graduates_logistic_regression_fairclean.ipynb
├── results/
│   ├── figures/
│   └── metrics/
└── docs/
    └── methodology.md
```

## Running the notebooks

1. Clone the repository.
2. Create a Python environment.
3. Install the dependencies:

```bash
pip install -r requirements.txt
```

4. Start Jupyter:

```bash
jupyter notebook
```

5. Run one of the notebooks in `notebooks/`.

The portfolio copies use repository-relative data paths rather than the original Google Drive paths used during development. The Adult processed dataset is included with attribution. The International Graduates CSV is intentionally omitted until its original distribution licence can be verified; see `data/README.md`.

## What I learned

This project strengthened my experience in:

- designing and testing an end-to-end analytical workflow;
- Python data manipulation with Pandas and NumPy;
- machine-learning modelling with scikit-learn;
- vectorised counterfactual testing;
- data-quality and fairness evaluation;
- comparing model behaviour rather than relying on a single result;
- documenting assumptions and limitations;
- building transparent, auditable data-processing logic.

## Limitations

FairClean is an academic research prototype, not a production fairness system. Its causal and structural rules are dataset-specific and depend on assumptions about which relationships should be treated as legitimate. Fairness is also context-dependent, so demographic parity and counterfactual tests should not be interpreted as complete measures of whether a real-world decision system is fair.

## Author

**Uyi Anslem Ezama**  
BSc (Hons) Computer Science — First-Class Honours  
Edinburgh Napier University

[LinkedIn](https://www.linkedin.com/in/uyi-ezama-b883a0331/) · [GitHub](https://github.com/Anslem30)


## Reusable Python package

The repeated notebook logic has been extracted into `src/fairclean/` so the core diagnostics, metrics and mitigation steps can be imported and tested independently. The original experiment notebooks remain in `notebooks/` as the research record.

Install the project in editable mode with:

```bash
pip install -e .[dev]
pytest -q
```

### Refactoring note

During the portfolio refactor I preserved the submitted notebooks unchanged as evidence of the original research implementation. The reusable mitigation function keeps stable row identifiers when rows are removed before structural reweighting. This avoids index ambiguity and is covered by a unit test. Because that implementation detail can affect row-weight assignment, the headline dissertation results in this README remain the **reported research results**, rather than being silently replaced by refactored outputs.

## Project status

This repository is a portfolio refactor of my 2026 Honours research prototype. The original experiment notebooks are retained as the research record, while reusable components and tests in `src/fairclean/` were added afterwards to improve code organisation, reproducibility and transparency.

The research prototype should not be used as an automated decision-making or compliance system.

# Data sources and attribution

## Adult Income

The Adult Income dataset is a public machine-learning benchmark from the **UCI Machine Learning Repository**.

- Dataset: Adult / Census Income
- Creators: Barry Becker and Ronny Kohavi
- Original data: 1994 Census database
- UCI DOI: `10.24432/C5XW20`
- Licence: **Creative Commons Attribution 4.0 International (CC BY 4.0)**
- Official page: https://archive.ics.uci.edu/dataset/2/adult

This repository includes `adult-income-preprocessed.csv`, the processed version used by the FairClean experiment notebooks. The transformation was produced as part of the Honours project. Users who want the original data should retrieve it from UCI and follow the attribution requirements above.

Suggested citation:

> Becker, B. & Kohavi, R. (1996). *Adult* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5XW20

## International Graduates

The International Graduates dataset was used as the second empirical dataset in the submitted research. The dissertation describes it as a contemporary employment/visa-related dataset containing demographic, educational and socioeconomic variables.

**The original distribution page and licence have not yet been verified confidently enough for redistribution.** For that reason, the CSV is intentionally **not included** in this public-ready repository.

The International Graduates notebooks remain available as a record of the research implementation and reported experiments. To reproduce those notebooks, place an authorised copy of the original dataset at:

```text
data/international-graduates.csv
```

Do not redistribute that dataset until its original source and licence have been confirmed.

## Why this matters

Keeping source and licence information explicit makes the repository easier to reproduce while respecting dataset ownership and attribution requirements.

# GitHub repository setup

## Repository name

`fairclean`

## Description

Fairness-aware data cleaning research prototype using Python, counterfactual testing and hybrid mitigation across employment-related ML datasets.

## Suggested topics

`python` `machine-learning` `data-cleaning` `responsible-ai` `algorithmic-fairness` `counterfactual-fairness` `scikit-learn` `data-quality` `fairness-in-ml`

## Website

If you later add a dedicated FairClean page to your portfolio website, use that page as the repository website. Otherwise leave this blank.

## Pin this repository

Once published, pin `fairclean` on your GitHub profile so it is one of the first projects recruiters see.

## Social preview

Use the main results visual from `results/figures/` as the basis for a repository social-preview image.

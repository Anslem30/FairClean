# Methodology

## Research question

FairClean investigates whether counterfactual reasoning can move beyond fairness diagnosis and guide targeted preprocessing interventions.

## Diagnostic layers

### 1. Sensitive-attribute flip
The protected attribute is changed while the remaining feature values are held constant. A changed prediction identifies direct model sensitivity to that attribute.

### 2. Causal counterfactual
The sensitive attribute is changed together with selected downstream features intended to represent causal pathways. This tests a broader form of sensitivity than the direct flip alone.

### 3. Structural uplift
Selected non-sensitive socioeconomic features are moved toward favourable values. Prediction changes under this test are treated differently from direct or causal sensitivity: the affected rows are reweighted rather than automatically removed.

## Hybrid mitigation

FairClean combines two interventions:

- **Removal:** rows identified by the direct or causal tests are removed from the cleaned training data.
- **Reweighting:** structurally unstable rows that remain are assigned a lower training weight.

A row-level cleaning log records diagnostic flags and the intervention applied.

## Evaluation

The prototype was evaluated with Logistic Regression and Decision Tree classifiers on the Adult Income and International Graduates datasets. Group-level demographic-parity measures were compared before and after mitigation, alongside counts from each counterfactual diagnostic.

The results demonstrate model-dependent behaviour. The Adult Logistic Regression experiment improved its demographic-parity gap, while the Adult Decision Tree did not. The International Graduates experiments showed almost no baseline demographic-parity disparity and no direct or causal instability.

## Important interpretation note

This framework is a research prototype. Counterfactual fairness depends on causal assumptions, and the dataset-specific uplift rules should not be interpreted as universal definitions of fairness.

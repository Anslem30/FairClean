# Portfolio copy

## CV — compact version

**FairClean — Fairness-Aware Data Cleaning Framework | Python, Pandas, scikit-learn**  
Developed and evaluated a fairness-aware preprocessing prototype across two employment-related datasets using Logistic Regression and Decision Tree models. Implemented counterfactual diagnostics, targeted removal/reweighting and transparent cleaning logs; the Adult Logistic Regression experiment reduced the reported demographic-parity gap from 0.3308 to 0.2427 (~26.6%).

## CV — conservative version for non-ML data roles

**FairClean — Data Quality & Machine Learning Research Project | Python, Pandas, scikit-learn**  
Designed a Python data-cleaning and evaluation workflow covering preprocessing, validation, model testing and transparent intervention logging across two datasets. Compared model behaviour before and after targeted cleaning and documented limitations and reproducibility considerations.

## LinkedIn project title

**FairClean — Fairness-Aware Data Cleaning for Machine Learning**

## LinkedIn project description

Developed FairClean as my BSc (Hons) Computer Science Honours project at Edinburgh Napier University.

The project investigates whether fairness considerations can be incorporated earlier in the machine-learning lifecycle during data preparation. I implemented a Python prototype using Pandas, NumPy and scikit-learn, evaluated it with Logistic Regression and Decision Tree models across the Adult Income and International Graduates datasets, and recorded row-level cleaning interventions for transparency.

In the Adult Income Logistic Regression experiment, the reported demographic-parity gap decreased from 0.3308 to 0.2427 (approximately 26.6%). The experiments also showed that the intervention did not improve every model, which became an important part of the evaluation and limitations.

Skills demonstrated: Python, Pandas, NumPy, scikit-learn, data cleaning, machine learning, data validation, model evaluation, responsible AI, technical documentation and reproducible research.

Add the GitHub repository URL after publishing.

## GitHub profile pinned-project line

**FairClean** — Python research prototype exploring fairness-aware data cleaning, counterfactual diagnostics and transparent mitigation in ML preprocessing.

## Interview explanation

“I built FairClean for my Honours project because I wanted to investigate whether fairness could be addressed during data preparation rather than only after a model had been trained. I tested the approach across two datasets and two classifiers. One of the strongest results was with Logistic Regression on Adult Income, where the demographic-parity gap fell by about 26.6%. But the Decision Tree did not show the same improvement, which taught me not to assume that a preprocessing intervention generalises across models. When I later prepared the project for my portfolio, I refactored repeated notebook logic into reusable Python modules, added tests and documented implementation limitations rather than hiding them.”

# Refactor notes

This repository separates the original research experiments from the portfolio refactor.

## Original research record

The four notebooks in `notebooks/` correspond to the submitted FairClean experiments. Their analytical logic and outputs are retained as the research record, apart from changing local/Google Drive dataset paths to repository-relative paths.

## Portfolio refactor

`src/fairclean/` extracts reusable logic for:

- demographic-parity metrics;
- direct sensitive-attribute counterfactual testing;
- dataset-specific structural uplift tests;
- hybrid removal/reweighting;
- model construction.

## Two implementation details documented explicitly

1. In the original notebooks, `causal_cf_fast` simply calls or reproduces the direct sensitive-attribute flip. The portfolio code therefore names it `causal_counterfactual_prototype` and documents that it is **not an independent causal model**.
2. The original mitigation code resets the cleaned DataFrame index before mapping structural row positions. The refactored implementation keeps a stable `_fairclean_row_id` during mitigation so structural weights are attached to the intended retained rows. The original reported dissertation results are not silently recalculated or rewritten because of this refactor.

These notes are included to make the repository transparent about the difference between the submitted academic prototype and later code-quality improvements.
